package org.top.currencysaverwebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurrencyConverterWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
