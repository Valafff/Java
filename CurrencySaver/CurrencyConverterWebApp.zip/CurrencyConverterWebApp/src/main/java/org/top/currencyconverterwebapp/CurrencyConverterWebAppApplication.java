package org.top.currencyconverterwebapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CurrencyConverterWebAppApplication {
	public static void main(String[] args) {
		SpringApplication.run(CurrencyConverterWebAppApplication.class, args);
	}
}
