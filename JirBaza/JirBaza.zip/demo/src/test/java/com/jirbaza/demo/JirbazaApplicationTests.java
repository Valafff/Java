package com.jirbaza.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JirbazaApplicationTests {

	@Test
	void contextLoads() {
	}

}
